import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLnJlZGVtcHRpb25tZWRpYQ==')

name = b.b64decode('UmVkZW1wdGlvbiBNZWRpYQ==')

host = b.b64decode('aHR0cDovL2ZsYXdsZXNzLWlwdHYubmV0')

port = b.b64decode('NDU0NQ==')